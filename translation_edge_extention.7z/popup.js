document.addEventListener('DOMContentLoaded', () => {
    const apiUrlInput = document.getElementById('apiUrl');
    const targetLangSelect = document.getElementById('targetLang');
    const saveBtn = document.getElementById('saveBtn');
    const status = document.getElementById('status');
    const openPdfButton = document.getElementById('openPdfButton');
    const pdfInput = document.getElementById('pdfInput');

    // --- Load saved settings ---
    chrome.storage.sync.get(['apiUrl', 'targetLang'], (result) => {
        apiUrlInput.value = result.apiUrl || 'http://localhost:8000/translate';
        targetLangSelect.value = result.targetLang || 'en';
    });

    // --- Save settings ---
    saveBtn.addEventListener('click', () => {
        const apiUrl = apiUrlInput.value.trim();
        const targetLang = targetLangSelect.value;

        if (!apiUrl) {
            showStatus('⚠️ Vui lòng nhập API URL!', 'error');
            return;
        }

        chrome.storage.sync.set({ apiUrl, targetLang }, () => {
            showStatus('✅ Đã lưu cài đặt!', 'success');

            // Gửi thông báo cho content script
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs[0]?.id) {
                    chrome.tabs.sendMessage(tabs[0].id, {
                        action: 'settingsUpdated',
                        apiUrl,
                        targetLang
                    });
                }
            });
        });
    });

    // --- Open PDF (chọn file & mở PDF.js viewer) ---
    openPdfButton.addEventListener('click', () => {
        pdfInput.click(); // mở hộp thoại chọn file
    });

    pdfInput.addEventListener('change', (event) => {
        const file = event.target.files[0];
        if (file) {
            const blobUrl = URL.createObjectURL(file);
            chrome.tabs.create({
                url: `/pdfjs/web/viewer.html?file=${encodeURIComponent(blobUrl)}`
            });
        } else {
            showStatus('⚠️ Bạn chưa chọn file PDF!', 'error');
        }
    });

    // --- Helper: Hiển thị thông báo trạng thái ---
    function showStatus(message, type) {
        status.textContent = message;
        status.className = `status ${type}`;
        setTimeout(() => {
            status.textContent = '';
            status.className = 'status';
        }, 3000);
    }
});
