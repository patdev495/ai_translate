document.addEventListener('DOMContentLoaded', function() {
    const apiUrlInput = document.getElementById('apiUrl');
    const targetLangSelect = document.getElementById('targetLang');
    const saveBtn = document.getElementById('saveBtn');
    const status = document.getElementById('status');

    // Load saved settings
    chrome.storage.sync.get(['apiUrl', 'targetLang'], function(result) {
        apiUrlInput.value = result.apiUrl || 'http://localhost:8000/translate';
        targetLangSelect.value = result.targetLang || 'en';
    });

    // Save settings
    saveBtn.addEventListener('click', function() {
        const apiUrl = apiUrlInput.value.trim();
        const targetLang = targetLangSelect.value;

        if (!apiUrl) {
            showStatus('Vui lòng nhập API URL!', 'error');
            return;
        }

        chrome.storage.sync.set({
            apiUrl: apiUrl,
            targetLang: targetLang
        }, function() {
            showStatus('Đã lưu cài đặt!', 'success');
            
            // Notify content script about settings update
            chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: 'settingsUpdated',
                    apiUrl: apiUrl,
                    targetLang: targetLang
                });
            });
        });
    });

    function showStatus(message, type) {
        status.textContent = message;
        status.className = `status ${type}`;
        setTimeout(() => {
            status.textContent = '';
            status.className = 'status';
        }, 3000);
    }
});