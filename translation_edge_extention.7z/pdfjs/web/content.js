// Thêm CSS trực tiếp trong content.js

class LocalTranslator {
    constructor() {
        // Ngăn tạo nhiều instance
        if (window.localTranslatorInitialized) return;
        window.localTranslatorInitialized = true;

        console.log('LocalTranslator initialized');

        this.settings = {
            apiUrl: 'http://localhost:8000/translate',
            targetLang: 'en'
        };
        this.tooltip = null;
        this.isTranslating = false;

        this.init();
    }

    async init() {
        await this.loadSettings();
        this.setupEventListeners();
    }

    async loadSettings() {
        return new Promise(resolve => {
            try {
                chrome.storage?.sync.get(['apiUrl', 'targetLang'], result => {
                    this.settings.apiUrl = result?.apiUrl || this.settings.apiUrl;
                    this.settings.targetLang = result?.targetLang || this.settings.targetLang;
                    resolve();
                }) || resolve();
            } catch (err) {
                console.warn('Failed to load settings:', err);
                resolve();
            }
        });
    }

    setupEventListeners() {
         document.addEventListener('mousedown', e => {
                if (!this.tooltip) return;

                // Nếu click không nằm trong tooltip
                if (!this.tooltip.contains(e.target)) {
                    this.hideTooltip();
                }
            });
        // Shift key để dịch
        document.addEventListener('keydown', e => {
            if (e.shiftKey && !e.ctrlKey && !e.altKey && !e.metaKey) {
                const activeTag = document.activeElement.tagName;
                if (activeTag === 'INPUT' || activeTag === 'TEXTAREA' || document.activeElement.isContentEditable) return;

                const selectedText = this.getSelectedText();
                if (selectedText) {
                    e.preventDefault();
                    this.handleTranslate(selectedText);
                }
            }
        });

        // ESC đóng tooltip
        document.addEventListener('keydown', e => {
            if (e.key === 'Escape') this.hideTooltip();
        });

        // Settings từ popup
        chrome.runtime?.onMessage.addListener(message => {
            if (message.action === 'settingsUpdated') {
                this.settings.apiUrl = message.apiUrl;
                this.settings.targetLang = message.targetLang;
                console.log('Settings updated:', this.settings);
            }
        });
    }

    getSelectedText() {
        return window.getSelection()?.toString().trim() || '';
    }

    async handleTranslate(text) {
        if (this.isTranslating || !text) return;
        await this.loadSettings();
        this.isTranslating = true;

        try {
            this.showLoadingTooltip();
            const translation = await this.translateText(text);
            const translatedStr = this.formatTranslation(translation);
            this.showTranslationTooltip(text, translatedStr);
        } catch (err) {
            console.error('Translation error:', err);
            this.showErrorTooltip(err.message);
        } finally {
            this.isTranslating = false;
        }
    }

    async translateText(text) {
        try {
            console.log('Translating text:', text, 'using API:', this.settings.apiUrl);
            const res = await fetch(this.settings.apiUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ text, tgt_lang: this.settings.targetLang })
            });
            const data = await res.json();
            console.log('Translation response:', data);
            return data;
        } catch (err) {
            console.error('Fetch error:', err);
            throw err;
        }
    }

    formatTranslation(data) {
    let translated = '';
    if (data.translated_text?.length) {
        translated += data.translated_text.join(' ');
    }
    if (data.pinyin_text?.length) {
        const pinyinStr = data.pinyin_text.join(' ').trim();
        if (pinyinStr) translated += ` (${pinyinStr})`;
    }
    return translated || '';
    }

    getSelectionCoordinates() {
        const selection = window.getSelection();
        if (!selection.rangeCount) return null;

        const range = selection.getRangeAt(0);
        let rect = range.getBoundingClientRect();

        // Fallback nếu rect.height = 0 (PDF.js textLayer)
        if (rect.height === 0 && range.startContainer.parentElement) {
            rect = range.startContainer.parentElement.getBoundingClientRect();
        }

        return {
            x: rect.left + rect.width / 2,
            y: rect.top,
            width: rect.width,
            height: rect.height
        };
    }

    getTooltipContainer() {
        return document.querySelector('.textLayer') || document.body;
    }

    showLoadingTooltip() {
        const coords = this.getSelectionCoordinates();
        if (!coords) return;

        this.hideTooltip();
        this.tooltip = document.createElement('div');
        this.tooltip.className = 'translator-tooltip loading';
        this.tooltip.style.position = 'absolute';
        this.tooltip.style.zIndex = 9999;
        this.tooltip.innerHTML = `
            <div class="tooltip-content">
                <div class="loading-spinner"></div>
                <div>Đang dịch...</div>
            </div>
        `;

        this.getTooltipContainer().appendChild(this.tooltip);
        this.positionTooltip(coords);
    }

    showTranslationTooltip(originalText, translation) {
        const coords = this.getSelectionCoordinates();
        if (!coords) return;

        this.hideTooltip();
        this.tooltip = document.createElement('div');
        this.tooltip.className = 'translator-tooltip';
        this.tooltip.style.position = 'absolute';
        this.tooltip.style.zIndex = 9999;

        const langNames = { en: 'English', vi: 'Tiếng Việt', zh: '中文简体', tzh: '中文繁體' };
        this.tooltip.innerHTML = `
            <div class="tooltip-content">
                <div class="tooltip-header">
                    <span class="lang-indicator">→ ${langNames[this.settings.targetLang]}</span>
                    <button class="close-btn">×</button>
                </div>
                <div class="original-text">${this.escapeHtml(originalText)}</div>
                <div class="translated-text">${this.escapeHtml(translation)}</div>
                <div class="tooltip-footer">
                    <span class="shortcut-hint">ESC để đóng</span>
                </div>
            </div>
        `;

        this.tooltip.querySelector('.close-btn').addEventListener('click', e => {
            e.stopPropagation();
            this.hideTooltip();
        });

        this.getTooltipContainer().appendChild(this.tooltip);
        this.positionTooltip(coords);
    }

    showErrorTooltip(error) {
        const coords = this.getSelectionCoordinates();
        if (!coords) return;

        this.hideTooltip();
        this.tooltip = document.createElement('div');
        this.tooltip.className = 'translator-tooltip error';
        this.tooltip.style.position = 'absolute';
        this.tooltip.style.zIndex = 9999;

        this.tooltip.innerHTML = `
            <div class="tooltip-content">
                <div class="tooltip-header">
                    <span class="error-indicator">❌ Lỗi dịch</span>
                    <button class="close-btn">×</button>
                </div>
                <div class="error-text">${this.escapeHtml(error)}</div>
                <div class="tooltip-footer">
                    <span class="shortcut-hint">Kiểm tra API local</span>
                </div>
            </div>
        `;

        this.tooltip.querySelector('.close-btn').addEventListener('click', e => {
            e.stopPropagation();
            this.hideTooltip();
        });

        this.getTooltipContainer().appendChild(this.tooltip);
        this.positionTooltip(coords);
    }

    positionTooltip(coords) {
    if (!this.tooltip || !coords) return;
    
    const tooltip = this.tooltip;
    const rect = tooltip.getBoundingClientRect();

    // Lấy container
    const container = this.getTooltipContainer();
    const containerRect = container.getBoundingClientRect();

    // Tính relative to container
    let left = coords.x - rect.width / 2 - containerRect.left;
    let top = coords.y - rect.height - 8 - containerRect.top; // offset 8px

    // Giới hạn trong viewport container
    const padding = 5;
    if (left < padding) left = padding;
    else if (left + rect.width > containerRect.width - padding) left = containerRect.width - rect.width - padding;
    if (top < padding) top = coords.y + coords.height + 8 - containerRect.top; // nếu tooltip không đủ chỗ trên

    tooltip.style.left = `${left}px`;
    tooltip.style.top = `${top}px`;
}

    hideTooltip() {
        if (this.tooltip) {
            this.tooltip.remove();
            this.tooltip = null;
        }
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Khởi tạo
new LocalTranslator();
