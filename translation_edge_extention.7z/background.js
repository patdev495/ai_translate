// Background script for Local Translator Extension

chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.sync.get(['apiUrl', 'targetLang'], (result) => {
        if (!result.apiUrl) {
            chrome.storage.sync.set({
                apiUrl: 'http://localhost:8000/translate',
                targetLang: 'zh'
            });
        }
    });
});

// Xử lý click icon extension (nếu có popup thì không cần thêm code)
chrome.action.onClicked.addListener((tab) => {
    // Popup đã được định nghĩa trong manifest, không cần làm gì thêm
});

// Xử lý phím tắt (nếu có cấu hình trong manifest)
chrome.commands?.onCommand?.addListener((command) => {
    if (command === 'translate-selection') {
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
            chrome.tabs.sendMessage(tabs[0].id, {
                action: 'translateSelection'
            });
        });
    }
});

// Lắng nghe message từ content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'getSettings') {
        chrome.storage.sync.get(['apiUrl', 'targetLang'], (result) => {
            sendResponse({
                apiUrl: result.apiUrl || 'http://localhost:8000/translate',
                targetLang: result.targetLang || 'en'
            });
        });
        return true;
    }

    if (message.action === 'translate') {
        chrome.storage.sync.get(['apiUrl', 'targetLang'], (result) => {
            const apiUrl = result.apiUrl || 'http://localhost:8000/translate';
            const targetLang = result.targetLang || 'en';

            fetch(apiUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    text: message.text,
                    tgt_lang: targetLang
                })
            })
            .then(res => res.json())
            .then(data => {
                sendResponse({ success: true, result: data });
            })
            .catch(err => {
                sendResponse({ success: false, error: err.message });
            });
        });
        return true; // Giữ channel mở cho async response
    }
});
