// Background script for Local Translator Extension

// Initialize default settings on install
chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.sync.get(['apiUrl', 'targetLang'], (result) => {
        if (!result.apiUrl) {
            chrome.storage.sync.set({
                apiUrl: 'http://localhost:8000/translate',
                targetLang: 'zh'
            });
        }
    });
});

// Handle extension icon click
chrome.action.onClicked.addListener((tab) => {
    // This will open the popup automatically
    // No additional action needed as popup is defined in manifest
});

// Optional: Handle keyboard shortcuts if you want to add them later
chrome.commands?.onCommand?.addListener((command) => {
    if (command === 'translate-selection') {
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
            chrome.tabs.sendMessage(tabs[0].id, {
                action: 'translateSelection'
            });
        });
    }
});

// Handle messages from content script (if needed)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'getSettings') {
        chrome.storage.sync.get(['apiUrl', 'targetLang'], (result) => {
            sendResponse({
                apiUrl: result.apiUrl || 'http://localhost:8000/translate',
                targetLang: result.targetLang || 'en'
            });
        });
        return true; // Keep message channel open for async response
    }
});