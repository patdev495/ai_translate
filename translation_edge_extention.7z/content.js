class LocalTranslator {
    constructor() {
        this.settings = {
            apiUrl: 'http://localhost:8000/translate',
            targetLang: 'en'
        };
        this.tooltip = null;
        this.isTranslating = false;
        this.init();
    }

    async init() {
        await this.loadSettings();
        this.setupEventListeners();
    }

    async loadSettings() {
        return new Promise((resolve) => {
            try {
                chrome.storage.sync.get(['apiUrl', 'targetLang'], (result) => {
                    this.settings.apiUrl = result?.apiUrl || 'http://localhost:8000/translate';
                    this.settings.targetLang = result?.targetLang || 'en';
                    resolve();
                });
            } catch (err) {
                console.warn('Failed to load settings (context invalidated):', err);
                resolve(); // fallback để không crash
            }
        });
    }

    setupEventListeners() {
        // Listen for Ctrl key press
        document.addEventListener('keydown', (e) => {

          if (e.shiftKey && !e.ctrlKey && !e.altKey && !e.metaKey) {
              const activeTag = document.activeElement.tagName;
              if (activeTag === 'INPUT' || activeTag === 'TEXTAREA' || document.activeElement.isContentEditable) {
                  return; // bỏ qua nếu đang focus input/textarea
              }

              const selectedText = this.getSelectedText();
              if (selectedText) {
                  e.preventDefault();
                  this.handleTranslate(selectedText);
                    }
                }
            });


        // Escape key closes tooltip
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.hideTooltip();
            }
        });

        // Click elsewhere hides tooltip
        document.addEventListener('click', () => {
            this.hideTooltip();
        });

        // Listen for settings updates from popup
        chrome.runtime.onMessage.addListener((message) => {
            if (message.action === 'settingsUpdated') {
                this.settings.apiUrl = message.apiUrl;
                this.settings.targetLang = message.targetLang;
                console.log('Settings updated:', this.settings);
            }
        });
    }

    getSelectedText() {
        const selection = window.getSelection();
        return selection.toString().trim();
    }

    async handleTranslate(text) {
        if (this.isTranslating || !text) return;
        await this.loadSettings(); // đảm bảo settings mới nhất
        this.isTranslating = true;

        try {
            this.showLoadingTooltip();
            const translation = await this.translateText(text);
            this.showTranslationTooltip(text, translation);
        } catch (error) {
            console.error('Translation error:', error);
            this.showErrorTooltip(error.message);
        } finally {
            this.isTranslating = false;
        }
    }

    async translateText(text) {
        const response = await fetch(this.settings.apiUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                text: text,
                tgt_lang: this.settings.targetLang
            })
        });

        if (!response.ok) throw new Error(`HTTP ${response.status}: ${response.statusText}`);

        const data = await response.json();

        if (data.translated_text) return data.translated_text;
        if (data.translation) return data.translation;
        if (data.result) return data.result;
        if (typeof data === 'string') return data;

        throw new Error('Unexpected API response format');
    }

    getSelectionCoordinates() {
        const selection = window.getSelection();
        if (selection.rangeCount > 0) {
            const rect = selection.getRangeAt(0).getBoundingClientRect();
            return { x: rect.left + rect.width / 2, y: rect.top, width: rect.width, height: rect.height };
        }
        return null;
    }

    showLoadingTooltip() {
        const coords = this.getSelectionCoordinates();
        if (!coords) return;

        this.hideTooltip();
        this.tooltip = document.createElement('div');
        this.tooltip.className = 'translator-tooltip loading';
        this.tooltip.innerHTML = `
            <div class="tooltip-content">
                <div class="loading-spinner"></div>
                <div>Đang dịch...</div>
            </div>
        `;
        document.body.appendChild(this.tooltip);
        this.positionTooltip(coords);
    }

    showTranslationTooltip(originalText, translation) {
        const coords = this.getSelectionCoordinates();
        if (!coords) return;

        this.hideTooltip();
        this.tooltip = document.createElement('div');
        this.tooltip.className = 'translator-tooltip';

        const langNames = { en: 'English', vi: 'Tiếng Việt', zh: '中文简体', tzh: '中文繁體' };
        this.tooltip.innerHTML = `
            <div class="tooltip-content">
                <div class="tooltip-header">
                    <span class="lang-indicator">→ ${langNames[this.settings.targetLang]}</span>
                    <button class="close-btn">×</button>
                </div>
                <div class="original-text">${this.escapeHtml(originalText)}</div>
                <div class="translated-text">${this.escapeHtml(translation)}</div>
                <div class="tooltip-footer">
                    <span class="shortcut-hint">ESC để đóng</span>
                </div>
            </div>
        `;

        this.tooltip.querySelector('.close-btn').addEventListener('click', (e) => {
            e.stopPropagation();
            this.hideTooltip();
        });

        document.body.appendChild(this.tooltip);
        this.positionTooltip(coords);
    }

    showErrorTooltip(error) {
        const coords = this.getSelectionCoordinates();
        if (!coords) return;

        this.hideTooltip();
        this.tooltip = document.createElement('div');
        this.tooltip.className = 'translator-tooltip error';
        this.tooltip.innerHTML = `
            <div class="tooltip-content">
                <div class="tooltip-header">
                    <span class="error-indicator">❌ Lỗi dịch</span>
                    <button class="close-btn">×</button>
                </div>
                <div class="error-text">${this.escapeHtml(error)}</div>
                <div class="tooltip-footer">
                    <span class="shortcut-hint">Kiểm tra API local</span>
                </div>
            </div>
        `;

        this.tooltip.querySelector('.close-btn').addEventListener('click', (e) => {
            e.stopPropagation();
            this.hideTooltip();
        });

        document.body.appendChild(this.tooltip);
        this.positionTooltip(coords);
    }

    positionTooltip(coords) {
        if (!this.tooltip) return;
        const tooltip = this.tooltip;
        const rect = tooltip.getBoundingClientRect();

        let left = coords.x - rect.width / 2;
        let top = coords.y - rect.height - 10;
        const padding = 10;

        if (left < padding) left = padding;
        else if (left + rect.width > window.innerWidth - padding) left = window.innerWidth - rect.width - padding;
        if (top < padding) top = coords.y + coords.height + 10;

        tooltip.style.left = left + 'px';
        tooltip.style.top = top + window.scrollY + 'px';
    }

    hideTooltip() {
        if (this.tooltip) {
            this.tooltip.remove();
            this.tooltip = null;
        }
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Initialize translator

const translator = new LocalTranslator();

